import { Head, Link, useForm } from '@inertiajs/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Lock, Mail, Shield, GraduationCap, Building2 } from 'lucide-react';

export default function Login({ status, canResetPassword }) {
    const { data, setData, post, processing, errors, reset } = useForm({
        email: '',
        password: '',
        remember: false,
    });

    const submit = (e) => {
        e.preventDefault();
        post(route('login'), {
            onFinish: () => reset('password'),
        });
    };

    return (
        <>
            <Head title="Administrator Login - EMBA Admission" />
            <div className="min-h-screen flex">
                {/* Left Side - Branding */}
                <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-blue-900 via-blue-800 to-slate-900 p-12 flex-col justify-between relative overflow-hidden">
                    <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS1vcGFjaXR5PSIwLjA1IiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-20"></div>
                    
                    <div className="relative z-10">
                        <div className="flex items-center gap-3 mb-8">
                            <div className="h-14 w-14 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/20">
                                <GraduationCap className="h-8 w-8 text-white" />
                            </div>
                            <div>
                                <h1 className="text-2xl font-bold text-white">EMBA Admission</h1>
                                <p className="text-blue-200 text-sm">Management Portal</p>
                            </div>
                        </div>
                    </div>

                    <div className="relative z-10 space-y-6">
                        <div>
                            <h2 className="text-4xl font-bold text-white mb-4 leading-tight">
                                Administrative Access Portal
                            </h2>
                            <p className="text-lg text-blue-100 leading-relaxed">
                                Secure login for authorized administrators to manage EMBA applications and admissions.
                            </p>
                        </div>

                        <div className="space-y-4 pt-8">
                            <div className="flex items-start gap-4 text-white/90">
                                <div className="mt-1 h-10 w-10 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0">
                                    <Shield className="h-5 w-5" />
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Secure Authentication</h3>
                                    <p className="text-sm text-blue-200">Protected access with enterprise-grade security</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-4 text-white/90">
                                <div className="mt-1 h-10 w-10 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0">
                                    <Building2 className="h-5 w-5" />
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Centralized Management</h3>
                                    <p className="text-sm text-blue-200">Complete control over the admission process</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="relative z-10 text-blue-200 text-sm">
                        <p>© 2025 Department of Management Studies</p>
                        <p className="text-blue-300">University of Barishal</p>
                    </div>
                </div>

                {/* Right Side - Login Form */}
                <div className="flex-1 flex items-center justify-center p-8 bg-slate-50">
                    <div className="w-full max-w-md">
                        <div className="mb-8 lg:hidden text-center">
                            <div className="inline-flex items-center justify-center h-16 w-16 bg-blue-900 rounded-xl mb-4">
                                <GraduationCap className="h-8 w-8 text-white" />
                            </div>
                            <h1 className="text-2xl font-bold text-slate-900">EMBA Admission</h1>
                        </div>

                        <Card className="border-0 shadow-2xl">
                            <CardHeader className="space-y-1 pb-6">
                                <CardTitle className="text-2xl font-bold">Administrator Login</CardTitle>
                                <CardDescription className="text-base">
                                    Enter your credentials to access the management portal
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                {status && (
                                    <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                                        <p className="text-sm font-medium text-green-800">{status}</p>
                                    </div>
                                )}

                                <form onSubmit={submit} className="space-y-5">
                                    <div className="space-y-2">
                                        <Label htmlFor="email" className="text-sm font-semibold">Email Address</Label>
                                        <div className="relative">
                                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                                            <Input
                                                id="email"
                                                type="email"
                                                value={data.email}
                                                onChange={(e) => setData('email', e.target.value)}
                                                className="pl-11 h-12 border-slate-300"
                                                placeholder="admin@university.edu"
                                                autoComplete="username"
                                                autoFocus
                                            />
                                        </div>
                                        {errors.email && (
                                            <p className="text-sm text-red-600 font-medium">{errors.email}</p>
                                        )}
                                    </div>

                                    <div className="space-y-2">
                                        <Label htmlFor="password" className="text-sm font-semibold">Password</Label>
                                        <div className="relative">
                                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                                            <Input
                                                id="password"
                                                type="password"
                                                value={data.password}
                                                onChange={(e) => setData('password', e.target.value)}
                                                className="pl-11 h-12 border-slate-300"
                                                placeholder="Enter your password"
                                                autoComplete="current-password"
                                            />
                                        </div>
                                        {errors.password && (
                                            <p className="text-sm text-red-600 font-medium">{errors.password}</p>
                                        )}
                                    </div>

                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center space-x-2">
                                            <Checkbox
                                                id="remember"
                                                checked={data.remember}
                                                onCheckedChange={(checked) => setData('remember', checked)}
                                            />
                                            <Label htmlFor="remember" className="text-sm font-medium cursor-pointer">
                                                Remember me
                                            </Label>
                                        </div>

                                        {canResetPassword && (
                                            <Link
                                                href={route('password.request')}
                                                className="text-sm font-semibold text-blue-900 hover:text-blue-700 transition-colors"
                                            >
                                                Forgot password?
                                            </Link>
                                        )}
                                    </div>

                                    <Button
                                        type="submit"
                                        disabled={processing}
                                        className="w-full h-12 bg-blue-900 hover:bg-blue-800 text-white font-semibold text-base"
                                    >
                                        {processing ? (
                                            <>
                                                <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                                                Signing in...
                                            </>
                                        ) : (
                                            'Sign In'
                                        )}
                                    </Button>
                                </form>

                                <div className="mt-6 text-center">
                                    <p className="text-sm text-slate-600">
                                        Not an administrator?{' '}
                                        <Link
                                            href={route('applicant.login')}
                                            className="font-semibold text-blue-900 hover:text-blue-700 transition-colors"
                                        >
                                            Applicant Login →
                                        </Link>
                                    </p>
                                </div>
                            </CardContent>
                        </Card>

                        <p className="text-center text-sm text-slate-500 mt-8">
                            By signing in, you agree to our terms of service and privacy policy.
                        </p>
                    </div>
                </div>
            </div>
        </>
    );
}
